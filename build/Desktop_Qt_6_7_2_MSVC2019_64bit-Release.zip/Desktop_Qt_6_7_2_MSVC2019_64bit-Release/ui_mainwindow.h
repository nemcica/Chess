/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *gridLayoutWidget;
    QGridLayout *ChessBoard;
    QTextEdit *textEdit_8;
    QTextEdit *textEdit_3;
    QPushButton *A3;
    QTextEdit *textEdit_12;
    QPushButton *A1;
    QTextEdit *cE;
    QTextEdit *textEdit_9;
    QPushButton *A2;
    QTextEdit *textEdit_17;
    QPushButton *C6;
    QPushButton *C8;
    QPushButton *E4;
    QPushButton *F1;
    QTextEdit *textEdit_19;
    QPushButton *F3;
    QPushButton *H8;
    QPushButton *H6;
    QPushButton *E3;
    QPushButton *F4;
    QPushButton *F6;
    QTextEdit *cD;
    QPushButton *A5;
    QPushButton *H1;
    QPushButton *H7;
    QPushButton *A8;
    QTextEdit *r2;
    QPushButton *C2;
    QPushButton *G6;
    QPushButton *B6;
    QPushButton *B4;
    QPushButton *F8;
    QPushButton *B5;
    QPushButton *D7;
    QTextEdit *r8;
    QPushButton *E6;
    QTextEdit *textEdit_11;
    QTextEdit *textEdit_15;
    QPushButton *H3;
    QPushButton *G1;
    QPushButton *H4;
    QPushButton *E7;
    QTextEdit *textEdit_4;
    QPushButton *C7;
    QPushButton *B8;
    QPushButton *E2;
    QPushButton *F2;
    QPushButton *B3;
    QPushButton *G3;
    QPushButton *D2;
    QTextEdit *r1;
    QTextEdit *cB;
    QPushButton *H5;
    QTextEdit *r3;
    QTextEdit *cA;
    QTextEdit *textEdit_6;
    QPushButton *G5;
    QTextEdit *cG;
    QPushButton *G7;
    QPushButton *A4;
    QPushButton *F7;
    QPushButton *D4;
    QPushButton *C4;
    QPushButton *B2;
    QPushButton *D6;
    QPushButton *E5;
    QPushButton *H2;
    QTextEdit *textEdit_5;
    QPushButton *G4;
    QTextEdit *textEdit_14;
    QTextEdit *textEdit_16;
    QTextEdit *r6;
    QTextEdit *cF;
    QPushButton *G2;
    QPushButton *G8;
    QTextEdit *textEdit_10;
    QTextEdit *textEdit_20;
    QPushButton *C1;
    QTextEdit *textEdit_13;
    QTextEdit *textEdit_0;
    QTextEdit *r5;
    QTextEdit *cH;
    QTextEdit *r7;
    QPushButton *B7;
    QPushButton *D1;
    QTextEdit *textEdit_7;
    QPushButton *D5;
    QPushButton *C3;
    QPushButton *A7;
    QPushButton *E8;
    QTextEdit *cC;
    QTextEdit *textEdit_18;
    QTextEdit *r4;
    QPushButton *E1;
    QPushButton *B1;
    QPushButton *F5;
    QPushButton *C5;
    QPushButton *A6;
    QPushButton *D3;
    QPushButton *D8;
    QTextEdit *textEdit_2;
    QLineEdit *Turn_player;
    QLineEdit *KingCheckLog;
    QWidget *formLayoutWidget;
    QHBoxLayout *promotionGrid;
    QPushButton *Queen;
    QPushButton *Knight;
    QPushButton *Bishop;
    QPushButton *Rook;
    QPushButton *pushButton;
    QTextEdit *moveLog;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setEnabled(true);
        MainWindow->resize(1200, 740);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(1200, 740));
        MainWindow->setMaximumSize(QSize(1200, 740));
        MainWindow->setMouseTracking(true);
        MainWindow->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color:brown;"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setStyleSheet(QString::fromUtf8("background-color:black;"));
        gridLayoutWidget = new QWidget(centralwidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(20, 20, 701, 701));
        ChessBoard = new QGridLayout(gridLayoutWidget);
        ChessBoard->setSpacing(0);
        ChessBoard->setObjectName("ChessBoard");
        ChessBoard->setSizeConstraint(QLayout::SizeConstraint::SetDefaultConstraint);
        ChessBoard->setContentsMargins(0, 0, 0, 0);
        textEdit_8 = new QTextEdit(gridLayoutWidget);
        textEdit_8->setObjectName("textEdit_8");
        textEdit_8->setMinimumSize(QSize(68, 68));
        textEdit_8->setMaximumSize(QSize(68, 68));
        textEdit_8->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_8->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_8->setReadOnly(true);

        ChessBoard->addWidget(textEdit_8, 8, 0, 1, 1);

        textEdit_3 = new QTextEdit(gridLayoutWidget);
        textEdit_3->setObjectName("textEdit_3");
        textEdit_3->setMinimumSize(QSize(68, 68));
        textEdit_3->setMaximumSize(QSize(68, 68));
        textEdit_3->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_3->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_3->setReadOnly(true);

        ChessBoard->addWidget(textEdit_3, 3, 0, 1, 1);

        A3 = new QPushButton(gridLayoutWidget);
        A3->setObjectName("A3");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(A3->sizePolicy().hasHeightForWidth());
        A3->setSizePolicy(sizePolicy1);
        A3->setMinimumSize(QSize(68, 68));
        A3->setMaximumSize(QSize(68, 68));
        A3->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(A3, 6, 1, 1, 1);

        textEdit_12 = new QTextEdit(gridLayoutWidget);
        textEdit_12->setObjectName("textEdit_12");
        textEdit_12->setMinimumSize(QSize(68, 68));
        textEdit_12->setMaximumSize(QSize(68, 68));
        textEdit_12->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_12->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_12->setReadOnly(true);

        ChessBoard->addWidget(textEdit_12, 0, 2, 1, 1);

        A1 = new QPushButton(gridLayoutWidget);
        A1->setObjectName("A1");
        sizePolicy1.setHeightForWidth(A1->sizePolicy().hasHeightForWidth());
        A1->setSizePolicy(sizePolicy1);
        A1->setMinimumSize(QSize(68, 68));
        A1->setMaximumSize(QSize(68, 68));
        A1->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(A1, 8, 1, 1, 1);

        cE = new QTextEdit(gridLayoutWidget);
        cE->setObjectName("cE");
        cE->setMinimumSize(QSize(68, 68));
        cE->setMaximumSize(QSize(68, 68));
        cE->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cE->setFrameShape(QFrame::Shape::NoFrame);
        cE->setReadOnly(true);

        ChessBoard->addWidget(cE, 9, 5, 1, 1);

        textEdit_9 = new QTextEdit(gridLayoutWidget);
        textEdit_9->setObjectName("textEdit_9");
        textEdit_9->setMinimumSize(QSize(68, 68));
        textEdit_9->setMaximumSize(QSize(68, 68));
        textEdit_9->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_9->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_9->setReadOnly(true);

        ChessBoard->addWidget(textEdit_9, 9, 0, 1, 1);

        A2 = new QPushButton(gridLayoutWidget);
        A2->setObjectName("A2");
        sizePolicy1.setHeightForWidth(A2->sizePolicy().hasHeightForWidth());
        A2->setSizePolicy(sizePolicy1);
        A2->setMinimumSize(QSize(68, 68));
        A2->setMaximumSize(QSize(68, 68));
        A2->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(A2, 7, 1, 1, 1);

        textEdit_17 = new QTextEdit(gridLayoutWidget);
        textEdit_17->setObjectName("textEdit_17");
        textEdit_17->setMinimumSize(QSize(68, 68));
        textEdit_17->setMaximumSize(QSize(68, 68));
        textEdit_17->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_17->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_17->setReadOnly(true);

        ChessBoard->addWidget(textEdit_17, 0, 7, 1, 1);

        C6 = new QPushButton(gridLayoutWidget);
        C6->setObjectName("C6");
        sizePolicy1.setHeightForWidth(C6->sizePolicy().hasHeightForWidth());
        C6->setSizePolicy(sizePolicy1);
        C6->setMinimumSize(QSize(68, 68));
        C6->setMaximumSize(QSize(68, 68));
        C6->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(C6, 3, 3, 1, 1);

        C8 = new QPushButton(gridLayoutWidget);
        C8->setObjectName("C8");
        sizePolicy1.setHeightForWidth(C8->sizePolicy().hasHeightForWidth());
        C8->setSizePolicy(sizePolicy1);
        C8->setMinimumSize(QSize(68, 68));
        C8->setMaximumSize(QSize(68, 68));
        C8->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(C8, 1, 3, 1, 1);

        E4 = new QPushButton(gridLayoutWidget);
        E4->setObjectName("E4");
        sizePolicy1.setHeightForWidth(E4->sizePolicy().hasHeightForWidth());
        E4->setSizePolicy(sizePolicy1);
        E4->setMinimumSize(QSize(68, 68));
        E4->setMaximumSize(QSize(68, 68));
        E4->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(E4, 5, 5, 1, 1);

        F1 = new QPushButton(gridLayoutWidget);
        F1->setObjectName("F1");
        sizePolicy1.setHeightForWidth(F1->sizePolicy().hasHeightForWidth());
        F1->setSizePolicy(sizePolicy1);
        F1->setMinimumSize(QSize(68, 68));
        F1->setMaximumSize(QSize(68, 68));
        F1->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(F1, 8, 6, 1, 1);

        textEdit_19 = new QTextEdit(gridLayoutWidget);
        textEdit_19->setObjectName("textEdit_19");
        textEdit_19->setMinimumSize(QSize(68, 68));
        textEdit_19->setMaximumSize(QSize(68, 68));
        textEdit_19->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_19->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_19->setReadOnly(true);

        ChessBoard->addWidget(textEdit_19, 0, 9, 1, 1);

        F3 = new QPushButton(gridLayoutWidget);
        F3->setObjectName("F3");
        sizePolicy1.setHeightForWidth(F3->sizePolicy().hasHeightForWidth());
        F3->setSizePolicy(sizePolicy1);
        F3->setMinimumSize(QSize(68, 68));
        F3->setMaximumSize(QSize(68, 68));
        F3->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(F3, 6, 6, 1, 1);

        H8 = new QPushButton(gridLayoutWidget);
        H8->setObjectName("H8");
        sizePolicy1.setHeightForWidth(H8->sizePolicy().hasHeightForWidth());
        H8->setSizePolicy(sizePolicy1);
        H8->setMinimumSize(QSize(68, 68));
        H8->setMaximumSize(QSize(68, 68));
        H8->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(H8, 1, 8, 1, 1);

        H6 = new QPushButton(gridLayoutWidget);
        H6->setObjectName("H6");
        sizePolicy1.setHeightForWidth(H6->sizePolicy().hasHeightForWidth());
        H6->setSizePolicy(sizePolicy1);
        H6->setMinimumSize(QSize(68, 68));
        H6->setMaximumSize(QSize(68, 68));
        H6->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(H6, 3, 8, 1, 1);

        E3 = new QPushButton(gridLayoutWidget);
        E3->setObjectName("E3");
        sizePolicy1.setHeightForWidth(E3->sizePolicy().hasHeightForWidth());
        E3->setSizePolicy(sizePolicy1);
        E3->setMinimumSize(QSize(68, 68));
        E3->setMaximumSize(QSize(68, 68));
        E3->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(E3, 6, 5, 1, 1);

        F4 = new QPushButton(gridLayoutWidget);
        F4->setObjectName("F4");
        sizePolicy1.setHeightForWidth(F4->sizePolicy().hasHeightForWidth());
        F4->setSizePolicy(sizePolicy1);
        F4->setMinimumSize(QSize(68, 68));
        F4->setMaximumSize(QSize(68, 68));
        F4->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(F4, 5, 6, 1, 1);

        F6 = new QPushButton(gridLayoutWidget);
        F6->setObjectName("F6");
        sizePolicy1.setHeightForWidth(F6->sizePolicy().hasHeightForWidth());
        F6->setSizePolicy(sizePolicy1);
        F6->setMinimumSize(QSize(68, 68));
        F6->setMaximumSize(QSize(68, 68));
        F6->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(F6, 3, 6, 1, 1);

        cD = new QTextEdit(gridLayoutWidget);
        cD->setObjectName("cD");
        cD->setMinimumSize(QSize(68, 68));
        cD->setMaximumSize(QSize(68, 68));
        cD->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cD->setFrameShape(QFrame::Shape::NoFrame);
        cD->setReadOnly(true);

        ChessBoard->addWidget(cD, 9, 4, 1, 1);

        A5 = new QPushButton(gridLayoutWidget);
        A5->setObjectName("A5");
        sizePolicy1.setHeightForWidth(A5->sizePolicy().hasHeightForWidth());
        A5->setSizePolicy(sizePolicy1);
        A5->setMinimumSize(QSize(68, 68));
        A5->setMaximumSize(QSize(68, 68));
        A5->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(A5, 4, 1, 1, 1);

        H1 = new QPushButton(gridLayoutWidget);
        H1->setObjectName("H1");
        sizePolicy1.setHeightForWidth(H1->sizePolicy().hasHeightForWidth());
        H1->setSizePolicy(sizePolicy1);
        H1->setMinimumSize(QSize(68, 68));
        H1->setMaximumSize(QSize(68, 68));
        H1->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(H1, 8, 8, 1, 1);

        H7 = new QPushButton(gridLayoutWidget);
        H7->setObjectName("H7");
        sizePolicy1.setHeightForWidth(H7->sizePolicy().hasHeightForWidth());
        H7->setSizePolicy(sizePolicy1);
        H7->setMinimumSize(QSize(68, 68));
        H7->setMaximumSize(QSize(68, 68));
        H7->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(H7, 2, 8, 1, 1);

        A8 = new QPushButton(gridLayoutWidget);
        A8->setObjectName("A8");
        A8->setEnabled(true);
        sizePolicy1.setHeightForWidth(A8->sizePolicy().hasHeightForWidth());
        A8->setSizePolicy(sizePolicy1);
        A8->setMinimumSize(QSize(68, 68));
        A8->setMaximumSize(QSize(68, 68));
        A8->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(A8, 1, 1, 1, 1);

        r2 = new QTextEdit(gridLayoutWidget);
        r2->setObjectName("r2");
        r2->setMinimumSize(QSize(68, 68));
        r2->setMaximumSize(QSize(68, 68));
        r2->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r2->setFrameShape(QFrame::Shape::NoFrame);
        r2->setReadOnly(true);

        ChessBoard->addWidget(r2, 7, 9, 1, 1);

        C2 = new QPushButton(gridLayoutWidget);
        C2->setObjectName("C2");
        sizePolicy1.setHeightForWidth(C2->sizePolicy().hasHeightForWidth());
        C2->setSizePolicy(sizePolicy1);
        C2->setMinimumSize(QSize(68, 68));
        C2->setMaximumSize(QSize(68, 68));
        C2->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(C2, 7, 3, 1, 1);

        G6 = new QPushButton(gridLayoutWidget);
        G6->setObjectName("G6");
        sizePolicy1.setHeightForWidth(G6->sizePolicy().hasHeightForWidth());
        G6->setSizePolicy(sizePolicy1);
        G6->setMinimumSize(QSize(68, 68));
        G6->setMaximumSize(QSize(68, 68));
        G6->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(G6, 3, 7, 1, 1);

        B6 = new QPushButton(gridLayoutWidget);
        B6->setObjectName("B6");
        sizePolicy1.setHeightForWidth(B6->sizePolicy().hasHeightForWidth());
        B6->setSizePolicy(sizePolicy1);
        B6->setMinimumSize(QSize(68, 68));
        B6->setMaximumSize(QSize(68, 68));
        B6->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(B6, 3, 2, 1, 1);

        B4 = new QPushButton(gridLayoutWidget);
        B4->setObjectName("B4");
        sizePolicy1.setHeightForWidth(B4->sizePolicy().hasHeightForWidth());
        B4->setSizePolicy(sizePolicy1);
        B4->setMinimumSize(QSize(68, 68));
        B4->setMaximumSize(QSize(68, 68));
        B4->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(B4, 5, 2, 1, 1);

        F8 = new QPushButton(gridLayoutWidget);
        F8->setObjectName("F8");
        sizePolicy1.setHeightForWidth(F8->sizePolicy().hasHeightForWidth());
        F8->setSizePolicy(sizePolicy1);
        F8->setMinimumSize(QSize(68, 68));
        F8->setMaximumSize(QSize(68, 68));
        F8->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(F8, 1, 6, 1, 1);

        B5 = new QPushButton(gridLayoutWidget);
        B5->setObjectName("B5");
        sizePolicy1.setHeightForWidth(B5->sizePolicy().hasHeightForWidth());
        B5->setSizePolicy(sizePolicy1);
        B5->setMinimumSize(QSize(68, 68));
        B5->setMaximumSize(QSize(68, 68));
        B5->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(B5, 4, 2, 1, 1);

        D7 = new QPushButton(gridLayoutWidget);
        D7->setObjectName("D7");
        sizePolicy1.setHeightForWidth(D7->sizePolicy().hasHeightForWidth());
        D7->setSizePolicy(sizePolicy1);
        D7->setMinimumSize(QSize(68, 68));
        D7->setMaximumSize(QSize(68, 68));
        D7->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(D7, 2, 4, 1, 1);

        r8 = new QTextEdit(gridLayoutWidget);
        r8->setObjectName("r8");
        r8->setMinimumSize(QSize(68, 68));
        r8->setMaximumSize(QSize(68, 68));
        r8->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r8->setFrameShape(QFrame::Shape::NoFrame);
        r8->setReadOnly(true);

        ChessBoard->addWidget(r8, 1, 9, 1, 1);

        E6 = new QPushButton(gridLayoutWidget);
        E6->setObjectName("E6");
        sizePolicy1.setHeightForWidth(E6->sizePolicy().hasHeightForWidth());
        E6->setSizePolicy(sizePolicy1);
        E6->setMinimumSize(QSize(68, 68));
        E6->setMaximumSize(QSize(68, 68));
        E6->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(E6, 3, 5, 1, 1);

        textEdit_11 = new QTextEdit(gridLayoutWidget);
        textEdit_11->setObjectName("textEdit_11");
        textEdit_11->setMinimumSize(QSize(68, 68));
        textEdit_11->setMaximumSize(QSize(68, 68));
        textEdit_11->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_11->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_11->setReadOnly(true);

        ChessBoard->addWidget(textEdit_11, 0, 1, 1, 1);

        textEdit_15 = new QTextEdit(gridLayoutWidget);
        textEdit_15->setObjectName("textEdit_15");
        textEdit_15->setMinimumSize(QSize(68, 68));
        textEdit_15->setMaximumSize(QSize(68, 68));
        textEdit_15->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_15->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_15->setReadOnly(true);

        ChessBoard->addWidget(textEdit_15, 0, 5, 1, 1);

        H3 = new QPushButton(gridLayoutWidget);
        H3->setObjectName("H3");
        sizePolicy1.setHeightForWidth(H3->sizePolicy().hasHeightForWidth());
        H3->setSizePolicy(sizePolicy1);
        H3->setMinimumSize(QSize(68, 68));
        H3->setMaximumSize(QSize(68, 68));
        H3->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(H3, 6, 8, 1, 1);

        G1 = new QPushButton(gridLayoutWidget);
        G1->setObjectName("G1");
        sizePolicy1.setHeightForWidth(G1->sizePolicy().hasHeightForWidth());
        G1->setSizePolicy(sizePolicy1);
        G1->setMinimumSize(QSize(68, 68));
        G1->setMaximumSize(QSize(68, 68));
        G1->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(G1, 8, 7, 1, 1);

        H4 = new QPushButton(gridLayoutWidget);
        H4->setObjectName("H4");
        sizePolicy1.setHeightForWidth(H4->sizePolicy().hasHeightForWidth());
        H4->setSizePolicy(sizePolicy1);
        H4->setMinimumSize(QSize(68, 68));
        H4->setMaximumSize(QSize(68, 68));
        H4->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(H4, 5, 8, 1, 1);

        E7 = new QPushButton(gridLayoutWidget);
        E7->setObjectName("E7");
        sizePolicy1.setHeightForWidth(E7->sizePolicy().hasHeightForWidth());
        E7->setSizePolicy(sizePolicy1);
        E7->setMinimumSize(QSize(68, 68));
        E7->setMaximumSize(QSize(68, 68));
        E7->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(E7, 2, 5, 1, 1);

        textEdit_4 = new QTextEdit(gridLayoutWidget);
        textEdit_4->setObjectName("textEdit_4");
        textEdit_4->setMinimumSize(QSize(68, 68));
        textEdit_4->setMaximumSize(QSize(68, 68));
        textEdit_4->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_4->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_4->setReadOnly(true);

        ChessBoard->addWidget(textEdit_4, 4, 0, 1, 1);

        C7 = new QPushButton(gridLayoutWidget);
        C7->setObjectName("C7");
        sizePolicy1.setHeightForWidth(C7->sizePolicy().hasHeightForWidth());
        C7->setSizePolicy(sizePolicy1);
        C7->setMinimumSize(QSize(68, 68));
        C7->setMaximumSize(QSize(68, 68));
        C7->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(C7, 2, 3, 1, 1);

        B8 = new QPushButton(gridLayoutWidget);
        B8->setObjectName("B8");
        sizePolicy1.setHeightForWidth(B8->sizePolicy().hasHeightForWidth());
        B8->setSizePolicy(sizePolicy1);
        B8->setMinimumSize(QSize(68, 68));
        B8->setMaximumSize(QSize(68, 68));
        B8->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(B8, 1, 2, 1, 1);

        E2 = new QPushButton(gridLayoutWidget);
        E2->setObjectName("E2");
        sizePolicy1.setHeightForWidth(E2->sizePolicy().hasHeightForWidth());
        E2->setSizePolicy(sizePolicy1);
        E2->setMinimumSize(QSize(68, 68));
        E2->setMaximumSize(QSize(68, 68));
        E2->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(E2, 7, 5, 1, 1);

        F2 = new QPushButton(gridLayoutWidget);
        F2->setObjectName("F2");
        sizePolicy1.setHeightForWidth(F2->sizePolicy().hasHeightForWidth());
        F2->setSizePolicy(sizePolicy1);
        F2->setMinimumSize(QSize(68, 68));
        F2->setMaximumSize(QSize(68, 68));
        F2->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(F2, 7, 6, 1, 1);

        B3 = new QPushButton(gridLayoutWidget);
        B3->setObjectName("B3");
        sizePolicy1.setHeightForWidth(B3->sizePolicy().hasHeightForWidth());
        B3->setSizePolicy(sizePolicy1);
        B3->setMinimumSize(QSize(68, 68));
        B3->setMaximumSize(QSize(68, 68));
        B3->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(B3, 6, 2, 1, 1);

        G3 = new QPushButton(gridLayoutWidget);
        G3->setObjectName("G3");
        sizePolicy1.setHeightForWidth(G3->sizePolicy().hasHeightForWidth());
        G3->setSizePolicy(sizePolicy1);
        G3->setMinimumSize(QSize(68, 68));
        G3->setMaximumSize(QSize(68, 68));
        G3->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(G3, 6, 7, 1, 1);

        D2 = new QPushButton(gridLayoutWidget);
        D2->setObjectName("D2");
        sizePolicy1.setHeightForWidth(D2->sizePolicy().hasHeightForWidth());
        D2->setSizePolicy(sizePolicy1);
        D2->setMinimumSize(QSize(68, 68));
        D2->setMaximumSize(QSize(68, 68));
        D2->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(D2, 7, 4, 1, 1);

        r1 = new QTextEdit(gridLayoutWidget);
        r1->setObjectName("r1");
        r1->setMinimumSize(QSize(68, 68));
        r1->setMaximumSize(QSize(68, 68));
        r1->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r1->setFrameShape(QFrame::Shape::NoFrame);
        r1->setReadOnly(true);

        ChessBoard->addWidget(r1, 8, 9, 1, 1);

        cB = new QTextEdit(gridLayoutWidget);
        cB->setObjectName("cB");
        cB->setMinimumSize(QSize(68, 68));
        cB->setMaximumSize(QSize(68, 68));
        cB->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cB->setFrameShape(QFrame::Shape::NoFrame);
        cB->setReadOnly(true);

        ChessBoard->addWidget(cB, 9, 2, 1, 1);

        H5 = new QPushButton(gridLayoutWidget);
        H5->setObjectName("H5");
        sizePolicy1.setHeightForWidth(H5->sizePolicy().hasHeightForWidth());
        H5->setSizePolicy(sizePolicy1);
        H5->setMinimumSize(QSize(68, 68));
        H5->setMaximumSize(QSize(68, 68));
        H5->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(H5, 4, 8, 1, 1);

        r3 = new QTextEdit(gridLayoutWidget);
        r3->setObjectName("r3");
        r3->setMinimumSize(QSize(68, 68));
        r3->setMaximumSize(QSize(68, 68));
        r3->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r3->setFrameShape(QFrame::Shape::NoFrame);
        r3->setReadOnly(true);

        ChessBoard->addWidget(r3, 6, 9, 1, 1);

        cA = new QTextEdit(gridLayoutWidget);
        cA->setObjectName("cA");
        cA->setMinimumSize(QSize(68, 68));
        cA->setMaximumSize(QSize(68, 68));
        cA->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cA->setFrameShape(QFrame::Shape::NoFrame);
        cA->setReadOnly(true);

        ChessBoard->addWidget(cA, 9, 1, 1, 1);

        textEdit_6 = new QTextEdit(gridLayoutWidget);
        textEdit_6->setObjectName("textEdit_6");
        textEdit_6->setMinimumSize(QSize(68, 68));
        textEdit_6->setMaximumSize(QSize(68, 68));
        textEdit_6->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_6->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_6->setReadOnly(true);

        ChessBoard->addWidget(textEdit_6, 6, 0, 1, 1);

        G5 = new QPushButton(gridLayoutWidget);
        G5->setObjectName("G5");
        sizePolicy1.setHeightForWidth(G5->sizePolicy().hasHeightForWidth());
        G5->setSizePolicy(sizePolicy1);
        G5->setMinimumSize(QSize(68, 68));
        G5->setMaximumSize(QSize(68, 68));
        G5->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(G5, 4, 7, 1, 1);

        cG = new QTextEdit(gridLayoutWidget);
        cG->setObjectName("cG");
        cG->setMinimumSize(QSize(68, 68));
        cG->setMaximumSize(QSize(68, 68));
        cG->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cG->setFrameShape(QFrame::Shape::NoFrame);
        cG->setReadOnly(true);

        ChessBoard->addWidget(cG, 9, 7, 1, 1);

        G7 = new QPushButton(gridLayoutWidget);
        G7->setObjectName("G7");
        sizePolicy1.setHeightForWidth(G7->sizePolicy().hasHeightForWidth());
        G7->setSizePolicy(sizePolicy1);
        G7->setMinimumSize(QSize(68, 68));
        G7->setMaximumSize(QSize(68, 68));
        G7->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(G7, 2, 7, 1, 1);

        A4 = new QPushButton(gridLayoutWidget);
        A4->setObjectName("A4");
        sizePolicy1.setHeightForWidth(A4->sizePolicy().hasHeightForWidth());
        A4->setSizePolicy(sizePolicy1);
        A4->setMinimumSize(QSize(68, 68));
        A4->setMaximumSize(QSize(68, 68));
        A4->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(A4, 5, 1, 1, 1);

        F7 = new QPushButton(gridLayoutWidget);
        F7->setObjectName("F7");
        sizePolicy1.setHeightForWidth(F7->sizePolicy().hasHeightForWidth());
        F7->setSizePolicy(sizePolicy1);
        F7->setMinimumSize(QSize(68, 68));
        F7->setMaximumSize(QSize(68, 68));
        F7->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(F7, 2, 6, 1, 1);

        D4 = new QPushButton(gridLayoutWidget);
        D4->setObjectName("D4");
        sizePolicy1.setHeightForWidth(D4->sizePolicy().hasHeightForWidth());
        D4->setSizePolicy(sizePolicy1);
        D4->setMinimumSize(QSize(68, 68));
        D4->setMaximumSize(QSize(68, 68));
        D4->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(D4, 5, 4, 1, 1);

        C4 = new QPushButton(gridLayoutWidget);
        C4->setObjectName("C4");
        sizePolicy1.setHeightForWidth(C4->sizePolicy().hasHeightForWidth());
        C4->setSizePolicy(sizePolicy1);
        C4->setMinimumSize(QSize(68, 68));
        C4->setMaximumSize(QSize(68, 68));
        C4->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(C4, 5, 3, 1, 1);

        B2 = new QPushButton(gridLayoutWidget);
        B2->setObjectName("B2");
        sizePolicy1.setHeightForWidth(B2->sizePolicy().hasHeightForWidth());
        B2->setSizePolicy(sizePolicy1);
        B2->setMinimumSize(QSize(68, 68));
        B2->setMaximumSize(QSize(68, 68));
        B2->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(B2, 7, 2, 1, 1);

        D6 = new QPushButton(gridLayoutWidget);
        D6->setObjectName("D6");
        sizePolicy1.setHeightForWidth(D6->sizePolicy().hasHeightForWidth());
        D6->setSizePolicy(sizePolicy1);
        D6->setMinimumSize(QSize(68, 68));
        D6->setMaximumSize(QSize(68, 68));
        D6->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(D6, 3, 4, 1, 1);

        E5 = new QPushButton(gridLayoutWidget);
        E5->setObjectName("E5");
        sizePolicy1.setHeightForWidth(E5->sizePolicy().hasHeightForWidth());
        E5->setSizePolicy(sizePolicy1);
        E5->setMinimumSize(QSize(68, 68));
        E5->setMaximumSize(QSize(68, 68));
        E5->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(E5, 4, 5, 1, 1);

        H2 = new QPushButton(gridLayoutWidget);
        H2->setObjectName("H2");
        sizePolicy1.setHeightForWidth(H2->sizePolicy().hasHeightForWidth());
        H2->setSizePolicy(sizePolicy1);
        H2->setMinimumSize(QSize(68, 68));
        H2->setMaximumSize(QSize(68, 68));
        H2->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(H2, 7, 8, 1, 1);

        textEdit_5 = new QTextEdit(gridLayoutWidget);
        textEdit_5->setObjectName("textEdit_5");
        textEdit_5->setMinimumSize(QSize(68, 68));
        textEdit_5->setMaximumSize(QSize(68, 68));
        textEdit_5->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_5->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_5->setReadOnly(true);

        ChessBoard->addWidget(textEdit_5, 5, 0, 1, 1);

        G4 = new QPushButton(gridLayoutWidget);
        G4->setObjectName("G4");
        sizePolicy1.setHeightForWidth(G4->sizePolicy().hasHeightForWidth());
        G4->setSizePolicy(sizePolicy1);
        G4->setMinimumSize(QSize(68, 68));
        G4->setMaximumSize(QSize(68, 68));
        G4->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(G4, 5, 7, 1, 1);

        textEdit_14 = new QTextEdit(gridLayoutWidget);
        textEdit_14->setObjectName("textEdit_14");
        textEdit_14->setMinimumSize(QSize(68, 68));
        textEdit_14->setMaximumSize(QSize(68, 68));
        textEdit_14->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_14->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_14->setReadOnly(true);

        ChessBoard->addWidget(textEdit_14, 0, 4, 1, 1);

        textEdit_16 = new QTextEdit(gridLayoutWidget);
        textEdit_16->setObjectName("textEdit_16");
        textEdit_16->setMinimumSize(QSize(68, 68));
        textEdit_16->setMaximumSize(QSize(68, 68));
        textEdit_16->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_16->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_16->setReadOnly(true);

        ChessBoard->addWidget(textEdit_16, 0, 6, 1, 1);

        r6 = new QTextEdit(gridLayoutWidget);
        r6->setObjectName("r6");
        r6->setMinimumSize(QSize(68, 68));
        r6->setMaximumSize(QSize(68, 68));
        r6->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r6->setFrameShape(QFrame::Shape::NoFrame);
        r6->setReadOnly(true);

        ChessBoard->addWidget(r6, 3, 9, 1, 1);

        cF = new QTextEdit(gridLayoutWidget);
        cF->setObjectName("cF");
        cF->setMinimumSize(QSize(68, 68));
        cF->setMaximumSize(QSize(68, 68));
        cF->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cF->setFrameShape(QFrame::Shape::NoFrame);
        cF->setReadOnly(true);

        ChessBoard->addWidget(cF, 9, 6, 1, 1);

        G2 = new QPushButton(gridLayoutWidget);
        G2->setObjectName("G2");
        sizePolicy1.setHeightForWidth(G2->sizePolicy().hasHeightForWidth());
        G2->setSizePolicy(sizePolicy1);
        G2->setMinimumSize(QSize(68, 68));
        G2->setMaximumSize(QSize(68, 68));
        G2->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(G2, 7, 7, 1, 1);

        G8 = new QPushButton(gridLayoutWidget);
        G8->setObjectName("G8");
        sizePolicy1.setHeightForWidth(G8->sizePolicy().hasHeightForWidth());
        G8->setSizePolicy(sizePolicy1);
        G8->setMinimumSize(QSize(68, 68));
        G8->setMaximumSize(QSize(68, 68));
        G8->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(G8, 1, 7, 1, 1);

        textEdit_10 = new QTextEdit(gridLayoutWidget);
        textEdit_10->setObjectName("textEdit_10");
        textEdit_10->setMinimumSize(QSize(68, 68));
        textEdit_10->setMaximumSize(QSize(68, 68));
        textEdit_10->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_10->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_10->setReadOnly(true);

        ChessBoard->addWidget(textEdit_10, 0, 0, 1, 1);

        textEdit_20 = new QTextEdit(gridLayoutWidget);
        textEdit_20->setObjectName("textEdit_20");
        textEdit_20->setMinimumSize(QSize(68, 68));
        textEdit_20->setMaximumSize(QSize(68, 68));
        textEdit_20->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_20->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_20->setReadOnly(true);

        ChessBoard->addWidget(textEdit_20, 9, 9, 1, 1);

        C1 = new QPushButton(gridLayoutWidget);
        C1->setObjectName("C1");
        sizePolicy1.setHeightForWidth(C1->sizePolicy().hasHeightForWidth());
        C1->setSizePolicy(sizePolicy1);
        C1->setMinimumSize(QSize(68, 68));
        C1->setMaximumSize(QSize(68, 68));
        C1->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(C1, 8, 3, 1, 1);

        textEdit_13 = new QTextEdit(gridLayoutWidget);
        textEdit_13->setObjectName("textEdit_13");
        textEdit_13->setMinimumSize(QSize(68, 68));
        textEdit_13->setMaximumSize(QSize(68, 68));
        textEdit_13->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_13->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_13->setReadOnly(true);

        ChessBoard->addWidget(textEdit_13, 0, 3, 1, 1);

        textEdit_0 = new QTextEdit(gridLayoutWidget);
        textEdit_0->setObjectName("textEdit_0");
        textEdit_0->setMinimumSize(QSize(68, 68));
        textEdit_0->setMaximumSize(QSize(68, 68));
        textEdit_0->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_0->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_0->setReadOnly(true);

        ChessBoard->addWidget(textEdit_0, 1, 0, 1, 1);

        r5 = new QTextEdit(gridLayoutWidget);
        r5->setObjectName("r5");
        r5->setMinimumSize(QSize(68, 68));
        r5->setMaximumSize(QSize(68, 68));
        r5->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r5->setFrameShape(QFrame::Shape::NoFrame);
        r5->setReadOnly(true);

        ChessBoard->addWidget(r5, 4, 9, 1, 1);

        cH = new QTextEdit(gridLayoutWidget);
        cH->setObjectName("cH");
        cH->setMinimumSize(QSize(68, 68));
        cH->setMaximumSize(QSize(68, 68));
        cH->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cH->setFrameShape(QFrame::Shape::NoFrame);
        cH->setReadOnly(true);

        ChessBoard->addWidget(cH, 9, 8, 1, 1);

        r7 = new QTextEdit(gridLayoutWidget);
        r7->setObjectName("r7");
        r7->setMinimumSize(QSize(68, 68));
        r7->setMaximumSize(QSize(68, 68));
        r7->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r7->setFrameShape(QFrame::Shape::NoFrame);
        r7->setReadOnly(true);

        ChessBoard->addWidget(r7, 2, 9, 1, 1);

        B7 = new QPushButton(gridLayoutWidget);
        B7->setObjectName("B7");
        sizePolicy1.setHeightForWidth(B7->sizePolicy().hasHeightForWidth());
        B7->setSizePolicy(sizePolicy1);
        B7->setMinimumSize(QSize(68, 68));
        B7->setMaximumSize(QSize(68, 68));
        B7->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(B7, 2, 2, 1, 1);

        D1 = new QPushButton(gridLayoutWidget);
        D1->setObjectName("D1");
        sizePolicy1.setHeightForWidth(D1->sizePolicy().hasHeightForWidth());
        D1->setSizePolicy(sizePolicy1);
        D1->setMinimumSize(QSize(68, 68));
        D1->setMaximumSize(QSize(68, 68));
        D1->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(D1, 8, 4, 1, 1);

        textEdit_7 = new QTextEdit(gridLayoutWidget);
        textEdit_7->setObjectName("textEdit_7");
        textEdit_7->setMinimumSize(QSize(68, 68));
        textEdit_7->setMaximumSize(QSize(68, 68));
        textEdit_7->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_7->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_7->setReadOnly(true);

        ChessBoard->addWidget(textEdit_7, 7, 0, 1, 1);

        D5 = new QPushButton(gridLayoutWidget);
        D5->setObjectName("D5");
        sizePolicy1.setHeightForWidth(D5->sizePolicy().hasHeightForWidth());
        D5->setSizePolicy(sizePolicy1);
        D5->setMinimumSize(QSize(68, 68));
        D5->setMaximumSize(QSize(68, 68));
        D5->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(D5, 4, 4, 1, 1);

        C3 = new QPushButton(gridLayoutWidget);
        C3->setObjectName("C3");
        sizePolicy1.setHeightForWidth(C3->sizePolicy().hasHeightForWidth());
        C3->setSizePolicy(sizePolicy1);
        C3->setMinimumSize(QSize(68, 68));
        C3->setMaximumSize(QSize(68, 68));
        C3->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(C3, 6, 3, 1, 1);

        A7 = new QPushButton(gridLayoutWidget);
        A7->setObjectName("A7");
        sizePolicy1.setHeightForWidth(A7->sizePolicy().hasHeightForWidth());
        A7->setSizePolicy(sizePolicy1);
        A7->setMinimumSize(QSize(68, 68));
        A7->setMaximumSize(QSize(68, 68));
        A7->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(A7, 2, 1, 1, 1);

        E8 = new QPushButton(gridLayoutWidget);
        E8->setObjectName("E8");
        sizePolicy1.setHeightForWidth(E8->sizePolicy().hasHeightForWidth());
        E8->setSizePolicy(sizePolicy1);
        E8->setMinimumSize(QSize(68, 68));
        E8->setMaximumSize(QSize(68, 68));
        E8->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(E8, 1, 5, 1, 1);

        cC = new QTextEdit(gridLayoutWidget);
        cC->setObjectName("cC");
        cC->setMinimumSize(QSize(68, 68));
        cC->setMaximumSize(QSize(68, 68));
        cC->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        cC->setFrameShape(QFrame::Shape::NoFrame);
        cC->setReadOnly(true);

        ChessBoard->addWidget(cC, 9, 3, 1, 1);

        textEdit_18 = new QTextEdit(gridLayoutWidget);
        textEdit_18->setObjectName("textEdit_18");
        textEdit_18->setMinimumSize(QSize(68, 68));
        textEdit_18->setMaximumSize(QSize(68, 68));
        textEdit_18->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_18->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_18->setReadOnly(true);

        ChessBoard->addWidget(textEdit_18, 0, 8, 1, 1);

        r4 = new QTextEdit(gridLayoutWidget);
        r4->setObjectName("r4");
        r4->setMinimumSize(QSize(68, 68));
        r4->setMaximumSize(QSize(68, 68));
        r4->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        r4->setFrameShape(QFrame::Shape::NoFrame);
        r4->setReadOnly(true);

        ChessBoard->addWidget(r4, 5, 9, 1, 1);

        E1 = new QPushButton(gridLayoutWidget);
        E1->setObjectName("E1");
        sizePolicy1.setHeightForWidth(E1->sizePolicy().hasHeightForWidth());
        E1->setSizePolicy(sizePolicy1);
        E1->setMinimumSize(QSize(68, 68));
        E1->setMaximumSize(QSize(68, 68));
        E1->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(E1, 8, 5, 1, 1);

        B1 = new QPushButton(gridLayoutWidget);
        B1->setObjectName("B1");
        sizePolicy1.setHeightForWidth(B1->sizePolicy().hasHeightForWidth());
        B1->setSizePolicy(sizePolicy1);
        B1->setMinimumSize(QSize(68, 68));
        B1->setMaximumSize(QSize(68, 68));
        B1->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(B1, 8, 2, 1, 1);

        F5 = new QPushButton(gridLayoutWidget);
        F5->setObjectName("F5");
        sizePolicy1.setHeightForWidth(F5->sizePolicy().hasHeightForWidth());
        F5->setSizePolicy(sizePolicy1);
        F5->setMinimumSize(QSize(68, 68));
        F5->setMaximumSize(QSize(68, 68));
        F5->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(F5, 4, 6, 1, 1);

        C5 = new QPushButton(gridLayoutWidget);
        C5->setObjectName("C5");
        sizePolicy1.setHeightForWidth(C5->sizePolicy().hasHeightForWidth());
        C5->setSizePolicy(sizePolicy1);
        C5->setMinimumSize(QSize(68, 68));
        C5->setMaximumSize(QSize(68, 68));
        C5->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(C5, 4, 3, 1, 1);

        A6 = new QPushButton(gridLayoutWidget);
        A6->setObjectName("A6");
        sizePolicy1.setHeightForWidth(A6->sizePolicy().hasHeightForWidth());
        A6->setSizePolicy(sizePolicy1);
        A6->setMinimumSize(QSize(68, 68));
        A6->setMaximumSize(QSize(68, 68));
        A6->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(A6, 3, 1, 1, 1);

        D3 = new QPushButton(gridLayoutWidget);
        D3->setObjectName("D3");
        sizePolicy1.setHeightForWidth(D3->sizePolicy().hasHeightForWidth());
        D3->setSizePolicy(sizePolicy1);
        D3->setMinimumSize(QSize(68, 68));
        D3->setMaximumSize(QSize(68, 68));
        D3->setStyleSheet(QString::fromUtf8("background-color: white;"));

        ChessBoard->addWidget(D3, 6, 4, 1, 1);

        D8 = new QPushButton(gridLayoutWidget);
        D8->setObjectName("D8");
        sizePolicy1.setHeightForWidth(D8->sizePolicy().hasHeightForWidth());
        D8->setSizePolicy(sizePolicy1);
        D8->setMinimumSize(QSize(68, 68));
        D8->setMaximumSize(QSize(68, 68));
        D8->setStyleSheet(QString::fromUtf8("background-color: orange;"));

        ChessBoard->addWidget(D8, 1, 4, 1, 1);

        textEdit_2 = new QTextEdit(gridLayoutWidget);
        textEdit_2->setObjectName("textEdit_2");
        textEdit_2->setMinimumSize(QSize(68, 68));
        textEdit_2->setMaximumSize(QSize(68, 68));
        textEdit_2->setStyleSheet(QString::fromUtf8("background-color:rgb(53, 53, 53);"));
        textEdit_2->setFrameShape(QFrame::Shape::NoFrame);
        textEdit_2->setReadOnly(true);

        ChessBoard->addWidget(textEdit_2, 2, 0, 1, 1);

        Turn_player = new QLineEdit(centralwidget);
        Turn_player->setObjectName("Turn_player");
        Turn_player->setGeometry(QRect(820, 20, 292, 42));
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(Turn_player->sizePolicy().hasHeightForWidth());
        Turn_player->setSizePolicy(sizePolicy2);
        QFont font;
        font.setFamilies({QString::fromUtf8("Sylfaen")});
        font.setPointSize(12);
        Turn_player->setFont(font);
        Turn_player->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        Turn_player->setStyleSheet(QString::fromUtf8("color: rgb(255, 170, 0);"));
        Turn_player->setAlignment(Qt::AlignmentFlag::AlignCenter);
        Turn_player->setReadOnly(true);
        KingCheckLog = new QLineEdit(centralwidget);
        KingCheckLog->setObjectName("KingCheckLog");
        KingCheckLog->setGeometry(QRect(820, 80, 292, 42));
        sizePolicy2.setHeightForWidth(KingCheckLog->sizePolicy().hasHeightForWidth());
        KingCheckLog->setSizePolicy(sizePolicy2);
        KingCheckLog->setFont(font);
        KingCheckLog->setStyleSheet(QString::fromUtf8("color: rgb(255, 170, 0);"));
        KingCheckLog->setAlignment(Qt::AlignmentFlag::AlignCenter);
        KingCheckLog->setReadOnly(true);
        formLayoutWidget = new QWidget(centralwidget);
        formLayoutWidget->setObjectName("formLayoutWidget");
        formLayoutWidget->setGeometry(QRect(730, 630, 355, 91));
        promotionGrid = new QHBoxLayout(formLayoutWidget);
        promotionGrid->setObjectName("promotionGrid");
        promotionGrid->setContentsMargins(0, 0, 0, 0);
        Queen = new QPushButton(formLayoutWidget);
        Queen->setObjectName("Queen");
        sizePolicy1.setHeightForWidth(Queen->sizePolicy().hasHeightForWidth());
        Queen->setSizePolicy(sizePolicy1);
        Queen->setMinimumSize(QSize(68, 68));
        Queen->setMaximumSize(QSize(68, 68));
        Queen->setStyleSheet(QString::fromUtf8("background-color: gray;"));

        promotionGrid->addWidget(Queen);

        Knight = new QPushButton(formLayoutWidget);
        Knight->setObjectName("Knight");
        sizePolicy1.setHeightForWidth(Knight->sizePolicy().hasHeightForWidth());
        Knight->setSizePolicy(sizePolicy1);
        Knight->setMinimumSize(QSize(68, 68));
        Knight->setMaximumSize(QSize(68, 68));
        Knight->setStyleSheet(QString::fromUtf8("background-color: gray;"));

        promotionGrid->addWidget(Knight);

        Bishop = new QPushButton(formLayoutWidget);
        Bishop->setObjectName("Bishop");
        sizePolicy1.setHeightForWidth(Bishop->sizePolicy().hasHeightForWidth());
        Bishop->setSizePolicy(sizePolicy1);
        Bishop->setMinimumSize(QSize(68, 68));
        Bishop->setMaximumSize(QSize(68, 68));
        Bishop->setStyleSheet(QString::fromUtf8("background-color: gray;"));

        promotionGrid->addWidget(Bishop);

        Rook = new QPushButton(formLayoutWidget);
        Rook->setObjectName("Rook");
        sizePolicy1.setHeightForWidth(Rook->sizePolicy().hasHeightForWidth());
        Rook->setSizePolicy(sizePolicy1);
        Rook->setMinimumSize(QSize(68, 68));
        Rook->setMaximumSize(QSize(68, 68));
        Rook->setStyleSheet(QString::fromUtf8("background-color: gray;"));

        promotionGrid->addWidget(Rook);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(1100, 640, 68, 68));
        pushButton->setMinimumSize(QSize(68, 68));
        pushButton->setMaximumSize(QSize(68, 68));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: gray; color: black;"));
        moveLog = new QTextEdit(centralwidget);
        moveLog->setObjectName("moveLog");
        moveLog->setGeometry(QRect(820, 150, 292, 460));
        moveLog->setFont(font);
        moveLog->setStyleSheet(QString::fromUtf8("color: rgb(255, 170, 0);"));
        moveLog->setReadOnly(true);
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        A3->setText(QString());
        A1->setText(QString());
        cE->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">E</span></p></body></html>", nullptr));
        A2->setText(QString());
        C6->setText(QString());
        C8->setText(QString());
        E4->setText(QString());
        F1->setText(QString());
        F3->setText(QString());
        H8->setText(QString());
        H6->setText(QString());
        E3->setText(QString());
        F4->setText(QString());
        F6->setText(QString());
        cD->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">D</span></p></body></html>", nullptr));
        A5->setText(QString());
        H1->setText(QString());
        H7->setText(QString());
        A8->setText(QString());
        r2->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  2</span></p></body></html>", nullptr));
        C2->setText(QString());
        G6->setText(QString());
        B6->setText(QString());
        B4->setText(QString());
        F8->setText(QString());
        B5->setText(QString());
        D7->setText(QString());
        r8->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  8</span></p></body></html>", nullptr));
        E6->setText(QString());
        H3->setText(QString());
        G1->setText(QString());
        H4->setText(QString());
        E7->setText(QString());
        C7->setText(QString());
        B8->setText(QString());
        E2->setText(QString());
        F2->setText(QString());
        B3->setText(QString());
        G3->setText(QString());
        D2->setText(QString());
        r1->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  1</span></p></body></html>", nullptr));
        cB->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">B</span></p></body></html>", nullptr));
        H5->setText(QString());
        r3->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  3</span></p></body></html>", nullptr));
        cA->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">A</span></p></body></html>", nullptr));
        G5->setText(QString());
        cG->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">G</span></p></body></html>", nullptr));
        G7->setText(QString());
        A4->setText(QString());
        F7->setText(QString());
        D4->setText(QString());
        C4->setText(QString());
        B2->setText(QString());
        D6->setText(QString());
        E5->setText(QString());
        H2->setText(QString());
        G4->setText(QString());
        r6->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  6</span></p></body></html>", nullptr));
        cF->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">F</span></p></body></html>", nullptr));
        G2->setText(QString());
        G8->setText(QString());
        C1->setText(QString());
        r5->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  5</span></p></body></html>", nullptr));
        cH->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">H</span></p></body></html>", nullptr));
        r7->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  7</span></p></body></html>", nullptr));
        B7->setText(QString());
        D1->setText(QString());
        D5->setText(QString());
        C3->setText(QString());
        A7->setText(QString());
        E8->setText(QString());
        cC->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">C</span></p></body></html>", nullptr));
        r4->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">  4</span></p></body></html>", nullptr));
        E1->setText(QString());
        B1->setText(QString());
        F5->setText(QString());
        C5->setText(QString());
        A6->setText(QString());
        D3->setText(QString());
        D8->setText(QString());
        Queen->setText(QString());
        Knight->setText(QString());
        Bishop->setText(QString());
        Rook->setText(QString());
        pushButton->setText(QCoreApplication::translate("MainWindow", "Reset", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
